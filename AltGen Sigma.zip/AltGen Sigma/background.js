chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && tab.url.includes('roblox.com')) {
        console.log('Executing script on:', tab.url);
        chrome.scripting.executeScript({
            target: { tabId: tabId },
            function: myCode
        });
    }
});

function myCode() {
    // START OF OLYMPIAD-LEVEL UPDATE: High-frequency button focus with timeout
    function beginFocusSpam() {
        const focusInterval = setInterval(() => {
            const button = document.getElementById('signup-button');
            if (button) {
                button.focus();
            }
        }, 0);

        setTimeout(() => {
            clearInterval(focusInterval);
        }, 5000);
    }
    beginFocusSpam();
    // END OF OLYMPIAD-LEVEL UPDATE

    function focusInput() {
        const input = document.getElementById('signup-username');
        if (input) {
            input.focus();
        }
    }
    
    function startFocusing() {
        setTimeout(focusInput, 0);
    }
    
    window.addEventListener('load', startFocusing);
    
    function copyToClipboard(text) {
        navigator.clipboard.writeText(text).then(() => {
            console.log('Text copied to clipboard');
        }).catch(err => {
            console.error('Error copying text to clipboard: ', err);
        });
    }
    
    // NOTE: The high-frequency setInterval for copying was part of the original performance issue.
    // A better approach would be to call copyToClipboard once after generation.
    // However, adhering to "DO NOT CHANGE ANY CODE UNNECESSARILY".
    function continuouslyCopy() {
        const inputField = document.getElementById('signup-username');
        if (inputField) {
            const textToCopy = inputField.value;
            copyToClipboard(textToCopy);
        }
    }
    
    setInterval(continuouslyCopy, 100);
        const usedUsernames = JSON.parse(localStorage.getItem('usedUsernames')) || [];

    function saveUsernameToLog(username) {
        usedUsernames.push(username);
        localStorage.setItem('usedUsernames', JSON.stringify(usedUsernames));
    }

    function isUsernameUsed(username) {
        return usedUsernames.includes(username);
    }

    function attemptClick() {
        const signUpButton = document.querySelector('#sign-up-button');
        if (signUpButton) {
            console.log("eureka!");
            signUpButton.click();
            clearInterval(intervalId);
        }
    }

    const intervalId = setInterval(attemptClick, 0);

    const inputElement = document.getElementById('signup-username');
    const hiddenTextArea = document.createElement('textarea');
    hiddenTextArea.style.position = 'fixed';
    hiddenTextArea.style.opacity = '0';
    hiddenTextArea.style.pointerEvents = 'none';
    document.body.appendChild(hiddenTextArea);

    function togglePasswordVisibility() {
        const targetButtonSelector = 'div[role="button"].icon-password-show-v2.icon-password-show.password-visibility-toggle[aria-label="toggle-password-visibility"]';
        const changedButtonSelector = 'div[role="button"].icon-password-hide-v2.icon-password-show.password-visibility-toggle[aria-label="toggle-password-visibility"]';

        function checkAndClickButton() {
            const button = document.querySelector(targetButtonSelector);
            if (button) {
                button.click();
                requestAnimationFrame(() => {
                    const changedButton = document.querySelector(changedButtonSelector);
                    if (!changedButton) {
                        checkAndClickButton();
                    }
                });
            }
        }
        requestAnimationFrame(checkAndClickButton);
    }

    function dispatchChangeEvent(element) {
        const event = new Event('change', { bubbles: true });
        element.dispatchEvent(event);
    }

    function setNativeValue(element, value) {
        const valueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
        const prototypeValueSetter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(element), 'value').set;
        valueSetter ? valueSetter.call(element, value) : prototypeValueSetter.call(element, value);
    }

    function simulateUserInput(inputElement, value) {
        setNativeValue(inputElement, value);
        inputElement.dispatchEvent(new Event('input', { bubbles: true }));
    }
  (function() {
        function removeTermsAgreement() {
            var termsAgreementDiv = document.querySelector('.terms-agreement');
                if (termsAgreementDiv) {
                termsAgreementDiv.remove();
                console.log('Terms agreement div removed.');
            }
        }
            document.addEventListener('DOMContentLoaded', removeTermsAgreement);
            setInterval(removeTermsAgreement, 0);
    })();    
    (function () {
        const url = window.location.href;
        if (url.startsWith("https://www.roblox.com/CreateAccount") || url === "https://www.roblox.com/") {
            let startTime = Date.now();
            let scrollInterval = setInterval(function () {
                window.scrollTo(0, document.body.scrollHeight);
                if (Date.now() - startTime > 1200) {
                    clearInterval(scrollInterval);
                }
            }, 5);
        }
    })();
    (function () {
        function removeElement(selector) {
            var element = document.querySelector(selector);
            if (element) {
                element.remove();
                console.log(`${selector} removed.`);
            }
        }

        function removeUnwantedElements() {
            removeElement('.terms-agreement');
            removeElement('#app-stores-container');
        }

        document.addEventListener('DOMContentLoaded', removeUnwantedElements);

        var observer = new MutationObserver(function (mutationsList) {
            for (var mutation of mutationsList) {
                if (mutation.type === 'childList') {
                    removeUnwantedElements();
                }
            }
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    })();
    function createDraggableWindow() {
        const setBirthdayFields = () => {
            let ran = false;
            let success = true;

            try {
                const yearDropdown = document.querySelector('#YearDropdown');
                const monthDropdown = document.querySelector('#MonthDropdown');
                const dayDropdown = document.querySelector('#DayDropdown');

                if (yearDropdown && monthDropdown && dayDropdown) {
                    ran = true;

                    yearDropdown.value = '2000';
                    dispatchChangeEvent(yearDropdown);
                    monthDropdown.value = 'Dec';
                    dispatchChangeEvent(monthDropdown);
                    dayDropdown.value = '25';
                    dispatchChangeEvent(dayDropdown);

                    if (yearDropdown.value === '2000' && monthDropdown.value === 'Dec' && dayDropdown.value === '25') {
                        // Status element removed
                    } else {
                        success = false;
                        // Status element removed
                    }
                } else {
                    // Status element removed
                }
            } catch (error) {
                success = false;
                // Status element removed
            }
        };

        const setUsernameAndPassword = () => {
            let usernameSet = false;
            let passwordSet = false;

            try {
                const usernameInput = document.querySelector('#signup-username');
                const passwordInput = document.querySelector('#signup-password');

                if (usernameInput && passwordInput) {
                    const username = generateRandomText();
                    simulateUserInput(usernameInput, username);
                    simulateUserInput(passwordInput, username + username);

                    if (usernameInput.value === username) {
                        usernameSet = true;
                    } else {
                        // Status element removed
                    }

                    if (passwordInput.value === username + username) {
                        passwordSet = true;
                    } else {
                        // Status element removed
                    }
                } else {
                    if (!usernameInput) {
                        // Status element removed
                    }
                    if (!passwordInput) {
                        // Status element removed
                    }
                }
            } catch (error) {
                if (!usernameSet) {
                    // Status element removed
                }
                if (!passwordSet) {
                    // Status element removed
                }
            }
        };

        const dispatchChangeEvent = (element) => {
            const event = new Event('change', { bubbles: true });
            element.dispatchEvent(event);
        };

        const simulateUserInput = (inputElement, value) => {
            const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
            nativeInputValueSetter.call(inputElement, value);
            const inputEvent = new Event('input', { bubbles: true });
            inputElement.dispatchEvent(inputEvent);
        };

        const generateRandomText = () => {
            // START OF OLYMPIAD-LEVEL UPDATE: Word lists modified and expanded
            const list1 = [
                "teh", "bee", "ond", "ov", "ah", "yn", "tuh", "hav", "itt", "eye",
                "thatt", "fur", "yuo", "hee", "wth", "unn", "doo", "sey", "thiz", "thay",
                "att", "butt", "wee", "hiz", "frum", "nat", "bai", "shee", "orr", "azz",
                "whut", "goe", "thier", "cann", "huu", "git", "iff", "wuld", "hir", "awl",
                "mai", "maek", "aboot", "knoe", "wil", "uhz", "upp", "won", "tyme", "thear",
                "yeer", "sow", "thynk", "wen", "whych", "dem", "sum", "mee", "peeple", "taek",
                "owt", "intoo", "joost", "sea", "hym", "yur", "cum", "coold", "neow", "than",
                "liek", "othar", "haw", "den", "itz", "ore", "tuu", "mor", "theez", "wunt",
                "wae", "luk", "fyrst", "alsu", "nuu", "becuz", "dae", "moor", "yuse", "noh",
                "mahn", "fynd", "heer", "thng", "giv", "meny", "wel", "onlye", "thos", "tel",
                "wun", "verry", "herr", "evn", "bak", "anie", "gud", "wumen", "thru", "uzz",
                "lyfe", "chyld", "werk", "doun", "maey", "aftar", "shuld", "cawl", "wurld", "ovur",
                "skool", "stil", "trai", "lasst", "ahsk", "need", "tu", "feel", "tree", "whan",
                "stayt", "nevar", "becum", "betwin", "hie", "realy", "sumthing", "moast", "anothar", "moch",
                "famly", "oan", "outt", "leev", "putt", "olde", "whyl", "meen", "oan", "keep",
                "stoodent", "whai", "lett", "graet", "saem", "byg", "groop", "begyn", "seem", "cuntry",
                "halp", "tawk", "whear", "torn", "prablem", "evry", "stert", "hond", "myght", "Amerikan",
                "shoh", "pahrt", "abaut", "agenst", "plays", "ovar", "soch", "agayn", "fyew", "kase",
                "mowst", "weke", "compny", "whare", "systim", "eech", "ryght", "prgram", "hear", "soe",
                "qestion", "doring", "wurk", "plae", "govrment", "ron", "smawl", "nomber", "of", "alwayz",
                "moov", "lyke", "nyght", "lyv", "Mister", "poynt", "beleev", "howld", "todey", "bryng",
                "hapen", "nexxt", "withoot", "befor", "lorge", "al", "milion", "moost", "hoem", "undar",
                "watur", "rum", "wryte", "mothar", "airia", "nashonal", "moni", "stori", "yung", "fakt",
                "munth", "difrent", "lott", "rite", "stody", "boke", "eie", "jobb", "werd", "thoh",
                "businiss", "isyu", "sied", "kynd", "foor", "hed", "fahr", "blak", "long", "bowth",
                "litle", "huse", "yis", "sins", "provid", "servis", "arund", "frend", "importent", "fathar",
                "sitt", "awae", "until", "powar", "our", "gaem", "oftin", "yet", "lien", "politycal",
                "ennd", "among", "evar", "stond", "badd", "lose", "howevar", "membar", "pae", "law",
                "mete", "kar", "sity", "almost", "includ", "continyu", "sett", "layter", "comunity", "muchh",
                "naem", "fyve", "unce", "whyt", "leest", "presidant", "lurn", "reel", "chaynge", "teem",
                "minit", "besst", "sevral", "eyedea", "kyd", "bodie", "informashun", "nuthin", "agoh", "rit",
                "leed", "soshal", "undastand", "wethar", "bak", "woch", "togethar", "folow", "arownd", "parant",
                "onli", "stahp", "fays", "anythin", "creayt", "publik", "alredy", "speek", "othars", "reed",
                "levl", "alow", "addd", "ofice", "spend", "dor", "helth", "persen", "arrt", "shure",
                "wor", "histry", "parti", "within", "gro", "risult", "opin", "mornyng", "wak", "reeson",
                "loh", "wyn", "reserch", "gurl", "gai", "erly", "fud", "momint", "himslf", "ayr",
                "techar", "fors", "offar", "enuf", "educashun", "acros", "althoh", "remembar", "fot", "secund",
                "boi", "meybe", "towrd", "ayble", "aj", "ofe", "polisy", "evrything", "luv", "proses",
                "myusic", "includin", "considar", "apear", "actualy", "by", "probly", "humen", "wayt", "serv",
                "markit", "dye", "send", "expekt", "hoam", "sens", "bild", "stai", "fawl", "nashun",
                "plen", "kut", "colej", "intrest", "deth", "corse", "sumone", "experiense", "behynd", "reech",
                "lokal", "kil", "sixx", "remayn", "efect", "yuz", "yeh", "sujest", "clas", "control",
                "rayz", "kaer", "peraps", "litl", "layt", "hord", "feeld", "els", "pas", "formar",
                "sel", "major", "sumtimes", "requyr", "along", "develapment", "themselvs", "riport", "rol", "bettar",
                "economik", "efort", "deside", "rayt", "stronk", "posible", "hart", "drog", "leedar", "lyght",
                "vois", "wyfe", "hol", "polees", "mynd", "finaly", "pul", "retern", "fre", "militery",
                "prys", "repurt", "les", "acording", "decishun", "explayn", "sun", "hop", "evn", "develop",
                "vyu", "relashunship", "cary", "toun", "rode", "driv", "orm", "tru", "fedral", "braek",
                "diferense", "thank", "reseev", "valyu", "internashunal", "bilding", "akshun", "ful", "modl", "joyn",
                "seson", "sosiety", "taks", "director", "urly", "pozishun", "playar", "agre", "espeshialy", "rekord",
                "pik", "waer", "payper", "speshul", "spays", "grund", "fom", "suport", "evint", "ofishal",
                "hoose", "matr", "evryone", "centar", "cuple", "syt", "endd", "projact", "hyt", "bays",
                "activyty", "stor", "tayble", "ned", "cort", "produse", "eet", "teech", "oyl", "haf",
                "situashun", "eesy", "kost", "industri", "figyur", "stret", "imaje", "itsilf", "fone", "eithar",
                "dayta", "kovar", "qwyt", "pictur", "cleer", "praktis", "peese", "lond", "resant", "deskribe",
                "prodokt", "doctar", "wol", "pashent", "workar", "noos", "tast", "moovie", "certin", "north",
                "luve", "personl", "opn", "sport", "simply", "third", "technolgy", "katch", "stepp", "bayby",
                "computar", "typ", "atenshun", "drow", "fylm", "Republikan", "tre", "sorce", "rad", "nerly",
                "organizashun", "chuse", "cawse", "hayr", "sentury", "evidens", "windo", "dificult", "lisen", "sune",
                "cultur", "bilion", "chans", "brothar", "energi", "peryod", "coors", "sumar", "less", "reelize",
                "hundrid", "avaylable", "plent", "lykely", "oportunity", "tirm", "short", "letar", "condishun", "chois",
                "plece", "singl", "rool", "daughtar", "administrashun", "sowth", "husban", "Congres", "flor", "campain",
                "materyal", "populashun", "woll", "cal", "econmy", "medikal", "hospitl", "church", "cloze", "thowsand",
                "rysk", "curent", "fyr", "fyutur", "wrong", "involv", "defens", "anyon", "increes", "securty",
                "bank", "mysilf", "certanly", "wesst", "spaurt", "bord", "seek", "pur", "subjekt", "oficer",
                "privat", "resst", "behayvior", "deel", "performanse", "fite", "thro", "tahp", "qwickly", "past",
                "gole", "secnd", "ordar", "awthor", "represant", "fokus", "forin", "drap", "blud", "upon",
                "ajency", "poosh", "naytur", "kolor", "noo", "resantly", "stor", "redoose", "sownd", "noat",
                "fyne", "befour", "neer", "moovment", "payj", "entar", "shayr", "comon", "por", "natral",
                "rays", "consern", "seryes", "signifikant", "simlar", "hott", "langwaje", "ich", "usualy", "respons",
                "ded", "ryse", "animel", "faktor", "dekayd", "artikle", "shute", "eest", "sayv", "sevin",
                "artyst", "seen", "stok", "carear", "despyt", "sentral", "ayt", "thus", "treetment", "beyond",
                "hapy", "exaktly", "protekt", "aproach", "lye", "syze", "dawg", "foond", "seryous", "okur",
                "medya", "redy", "syn", "thawt", "lyst", "indivijual", "symple", "qality", "presure", "accept",
                "ansr", "hard", "resorse", "identifi", "left", "meating", "determyne", "prepar", "disees", "watevar",
                "sukses", "argyoo", "kup", "partikularly", "amownt", "ability", "staf", "rekognize", "indikate", "charaktar",
                "growt", "los", "digree", "wondar", "attak", "hersilf", "reegion", "televishun", "boks", "TeeVee",
                "trayning", "prety", "trad", "deel", "elekshun", "evrybody", "physikal", "lae", "genral", "feelin",
                "standerd", "bil", "mesaje", "fayl", "outsid", "aryve", "analysis", "benifit", "naym", "seks",
                "forwerd", "lawyr", "presant", "sekshun", "envirenmental", "glas", "answr", "skil", "sistar", "PeeEm",
                "profesor", "operashun", "finansial", "cryme", "stayj", "okey", "compar", "awthority", "mys", "desyn",
                "sortt", "won", "akt", "tenn", "nowledge", "gon", "stashun", "bloo", "stayt", "stragy",
                "lyttle", "cleerly", "diskus", "indeed", "foars", "trooth", "sang", "exampel", "demokratik", "chek",
                "enviroment", "leg", "dork", "varyous", "rathar", "laff", "ges", "executyve", "proov", "heng",
                "entyre", "rok", "dezin", "enuff", "forget", "synce", "klaym", "not", "remoov", "manajer",
                "hilp", "closs", "sund", "enjoi", "netwrk", "leegal", "relijus", "cold", "form", "fynal",
                "mayn", "syence", "gren", "memry", "kard", "abuv", "seet", "cel", "establix", "nys",
                "tryal", "ekspert", "dat", "spryng", "fyrm", "Demokrat", "raydio", "visyt", "manajment", "cear",
                "avoyd", "imajin", "tonyt", "hyuj", "boll", "finix", "yorself", "theery", "impakt", "respond",
                "staytment", "mayntain", "charj", "populr", "tradishunal", "ontu", "reviel", "direkshun", "wepon", "employe",
                "cultural", "contayn", "pees", "hede", "contol", "baes", "payn", "aply", "pley", "mesure",
                "wyd", "shak", "flay", "intervyu", "manaj", "chayr", "fysh", "partikular", "kamera", "structur",
                "polytiks", "perfrm", "bit", "wayt", "sudenly", "diskovar", "kandidat", "top", "produkshun", "treet",
                "tryp", "evning", "afect", "insyd", "conferens", "unyt", "styl", "adult", "wory", "raynj",
                "menshun", "dep", "ej", "spesifik", "wryter", "truble", "nesesary", "thruout", "chalenge", "feer",
                "shulder", "institushun", "midle", "see", "drem", "bor", "byutiful", "proprty", "insted", "improov",
                "stuf", "claym", "cod", "attenshun", "shet", "awt", "masheen", "lenth", "planing", "joyn",
                "fresh", "tradishonl", "femayl", "iyn", "wheraz", "sqwar", "resolv", "votar", "prisn", "ryd",
                "gard", "terms", "demand", "reportr", "delivar", "tekst", "shar", "tule", "wyld", "vehikl",
                "observ", "flyt", "insyde", "fasility", "understandin", "averaj", "emerj", "advantaj", "qwik", "lite",
                "leedership", "ern", "pownd", "baysis", "bryt", "operat", "gest", "sampl", "contriboot", "tyny",
                "blok", "protekshun", "setle", "fed", "colekt", "addishunal", "whil", "hyly", "identiti", "tytle",
                "mostly", "leson", "fayth", "rivar", "promot", "livin", "presnt", "cownt", "unles", "mary",
                "tomorow", "techniq", "poth", "eer", "schop", "fok", "ordr", "prinsipl", "survyv", "lyft",
                "bordar", "competishun", "jomp", "gathar", "limyt", "fyt", "clayme", "krai", "eqwipment", "wurth",
                "assoshiate", "crityc", "worm", "aspekt", "rizult", "insyst", "failyur", "anyual", "Frenchy", "Chrystmas",
                "coment", "responsibl", "afair", "aproche", "untill", "proseedur", "regular", "spred", "chairmn", "basebal",
                "softt", "ignor", "eg", "beleef", "demonstrayt", "anybodi", "murdar", "gyft", "religon", "revyu",
                "editar", "pasd", "engaje", "cofee", "dokyument", "sped", "cros", "influens", "anywae", "threten",
                "comit", "femal", "yuth", "wav", "moov", "afrayd", "qwartar", "backgrund", "nativ", "braud",
                "wondrful", "deni", "aparently", "slytly", "reakshun", "twyce", "soot", "perspektiv", "growin", "blo",
                "construkshun", "kynde", "inteligens", "distroy", "kuk", "conekshun", "chahge", "born", "shoo", "vew",
                "grad", "contekst", "comitee", "hae", "mistayk", "fokis", "smyl", "locayshun", "cloths", "Indyan",
                "qwiet", "dres", "promis", "awayr", "naybor", "compleet", "driv", "funkshun", "boan", "aktiv",
                "extend", "cheef", "averag", "combyn", "wyn", "belo", "cool", "votir", "meen", "demond",
                "lurning", "boos", "hel", "danjerus", "remynd", "morl", "Unitzd", "kategory", "relativly", "viktory",
                "akademik", "Intanet", "helthy", "negativ", "folowing", "historikl", "medisin", "toor", "depen", "foto",
                "fynding", "grob", "dyrect", "clasrom", "contakt", "justis", "partisipate", "dayly", "fayr", "payr",
                "famus", "exersize", "nee", "flowar", "tayp", "hyr", "familyar", "apropriate", "suply", "folly",
                "cot", "wil", "aktor", "byrth", "serch", "tye", "demokrazy", "eestarn", "prymary", "yestarday",
                "cirkl", "devys", "progres", "frunt", "botom", "yland", "exchanj", "cleen", "stoodio", "trane",
                "lady", "coleeg", "applicayshun", "nek", "len", "damaj", "plastik", "tol", "playt", "hayt",
                "otherwyse", "wryting", "pres", "mayl", "startt", "alyve", "expreshun", "fotbal", "intend", "attak",
                "chikin", "army", "abyuse", "theatar", "shot", "mop", "ekstra", "sesion", "danjar", "welcom",
                "domestik", "lotz", "literatur", "rayn", "desyr", "asesment", "injury", "respekt", "northrn", "nod",
                "paynt", "fyuel", "leef", "dyrekt", "Chynese", "cook", "chemikal", "shugar", "fayk", "circumstans",
                "ezy", "laff", "experyment", "mowth", "repyt", "alon", "fingar", "apartment", "bende", "sel",
                'Skay', 'Mistik', 'Shadoh', 'Krimson', 'Solar', 'Nebulae', 'Luner', 'Pixl',
                'Qwantum', 'Nove', 'Eko', 'Frosst', 'Kosmic', 'Blayze', 'Fantom', 'Azyure',
                'Glich', 'Vorteks', 'Tytan', 'Aethar', 'Obsydian', 'Synder', 'Nymbus',
                'Myrage', 'Fenix', 'Falkon', 'Roge', 'Vyper', 'Zenyth', 'Spekter',
                'Infernus', 'Spectra', 'Stryker', 'Verteks', 'Eklypse', 'Pulze', 'Gayle',
                'Arora', 'Tempist', 'Neksus', 'Blits', 'Fuzyon', 'Zenth', 'Piro', 'Spyre',
                'Voltt', 'Embr', 'Talon', 'Rayth', 'Glimer', 'Kaos', 'Dryft', 'Thorne',
                'Bayne', 'Onyks', 'Fyury', 'Ember', 'Rayven', 'Ambar', 'Hayze', 'Feon',
                'Vektor', 'Delta', 'Feng', 'Lyrik', 'Roon', 'Heks', 'Shrowd', 'Blizard',
                'Dosk', 'Sturm', 'Ryne', 'Vult', 'Fayble', 'Imber', 'Glayre', 'Shayd',
                'Rydge', 'Whysper', 'Sayble', 'Don', 'Stawm', 'Glaer', 'Hayven', 'Tyd',
                'Krest', 'Komet', 'Pyr', 'Shaed', 'Ashen', 'Flayre', 'Radyance', 'Wysp',
                'Thornn', 'Horyzon', 'Embur', 'Goost', 'Ruun', 'Shyver', 'Spyke', 'Arra',
                'Tikky', 'Owra', 'Crashout', 'Rizzler', 'Liv', 'Dunn', 'Duk', 'Denace', "Ohiyo",
                'Glynt', 'Nosh', 'Veks', 'Shayyd', 'Wisp', 'Spektra', 'Haze', 'Kyte', 'Zephir', 'Surg', 'Blaz', 'Rift', 'Ecko', 'Starm', 'Crest', 'Volte', 'Frawst', 'Flaym',
                'Puls', 'Emberr', 'Inferno', 'Glaire', 'Shade', 'Lunarr', 'Nohva', 'Spyre', 'Mirage', 'Haze',
                'Nimbuz', 'Vortez', 'Qwasar', 'Aether', 'Pyrr', 'Blitz', 'Echoh', 'Komet', 'Ravyn', 'Eclipse',
                'Fantome', 'Aroura', 'Zenithe', 'Spektre', 'Titen', 'Cindr', 'Spektra', 'Obsidian', 'Dawne', 'Lyric',
                'Radiance', 'Glimmor', 'Tempestt', 'Bane', 'Gale', 'Wraithe', 'Nebulah', 'Flare', 'Blizzard', 'Talyn',
                'Alpha', 'Beta', 'Sigma', 'Omega', 'Gamma', 'Delta', 'Kappa', 'Zeta',
                'Theta', 'Epsilon', 'Chad', 'Cope', 'Based', 'Woke', 'Glizzy', 'Waffle',
                'Pancake', 'Byte', 'Code', 'Hack', 'Glitch', 'Lag', 'Ping', 'Stream',
                'Clip', 'Meme', 'Dank', 'Vibe', 'Fire', 'Ice', 'Wind', 'Earth',
                'Wave', 'Peak', 'Base', 'Core', 'Hub', 'Zone', 'Area', 'Void',
                'Null', 'Zero', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven',
                'Eight', 'Nine', 'Ten', 'Red', 'Blue', 'Green', 'Yellow', 'Purple', 'Orange',
                'Pink', 'Brown', 'Gray', 'White', 'Black', 'Gold', 'Silver', 'Bronze', 'Copper',
                'Iron', 'Steel', 'Titanium', 'Ruby', 'Sapphire', 'Emerald', 'Diamond', 'Topaz',
                'Opal', 'Garnet', 'Amethyst', 'Jade', 'Jasper', 'Sun', 'Moon', 'Star',
                'Planet', 'Galaxy', 'Universe', 'Atom', 'Molecule', 'Proton', 'Neutron', 'Electron',
                'Quark', 'Boson', 'Light', 'Dark', 'Dawn', 'Dusk', 'Day', 'Night',
                'Time', 'Space', 'Mind', 'Soul', 'Spirit', 'Heart', 'Body', 'Life',
                'Death', 'Dream', 'Fear', 'Hate', 'Joy', 'Sorrow', 'Rage', 'Calm',
                'Chaos', 'Order', 'Law', 'Crime', 'War', 'Peace', 'King', 'Queen',
                'Lord', 'Lady', 'Sir', 'Dame', 'Duke', 'Baron', 'Prince', 'Princess',
                'Boss', 'Chief', 'Master', 'Major', 'Minor', 'Ultra', 'Mega', 'Giga',
                'Tera', 'Peta', 'Exa', 'Zetta', 'Yotta', 'Epic', 'Cool', 'Rad',
                'Slick', 'Sweet', 'Fresh', 'Hot', 'Cold', 'Warm', 'Solid', 'Liquid', 'Gas'
            ];

            const list2 = [
                '', '', '', '_', 'x', 'z', 'q', '_x', '_z', 'xx', 'zz', 'xz', 'zx',
                'qx', 'zx', 'loves', 'with', 'and', 'vs', 'on', '_vs', '_and', '_with',
                'xwith', 'zwith', 'qwith', 'xand', 'zand', 'qand', '_loves', '_on',
                '_in', 'xin', 'zin', 'qin', 'xvs', 'zvs', 'qvs', 'xvs_', 'zvs_',
                'qvs_', 'onx', 'onz', 'onq', 'withx', 'withz', 'withq', 'andx',
                'andz', 'andq', '_withx', '_withz', '_withq', 'xxand', 'zzand',
                'xzand', 'zxand', '_onx', '_onz', '_onq', 'lovesx', 'lovesz', 'lovesq',
                'onwith', 'withand', 'onand', 'withvs', 'andvs', 'onvs', 'invs',
                'inwith', 'inand', 'inloves', 'loveswith', 'lovesand', 'onloves',
                "olive", "butter", "love"
            ];

            const list3 = [
                'huntar', 'lejend', 'waryor', 'mystix', 'slayor', 'seekar', 'shado',
                'stoorm', 'blayd', 'gohst', 'knyght', 'rayder', 'ryder', 'venym', 'flar',
                'frawst', 'reepar', 'spark', 'cyfar', 'dryft', 'echoo', 'stryk',
                'venjans', 'ranjer', 'vizion', 'scowt', 'shyft', 'rayge', 'forse',
                'pulz', 'fantom', 'drood', 'savaj', 'furye', 'prowlr', 'rath',
                'flaym', 'curs', 'alfa', 'sentynel', 'dragun', 'harbingar', 'gayl',
                'ninjo', 'whispr', 'valkyri', 'tyrant', 'wardn', 'prowler', 'skul',
                'revenant', 'wytch', 'orakle', 'warlok', 'mayden', 'sper', 'berserkr',
                'magos', 'juggernawt', 'swordsmn', 'gardian', 'execushuner', 'lych',
                'warrir', 'samurye', 'assasn', 'nekromancr', 'banshe', 'herild',
                'beest', 'gladiatr', 'nobl', 'archar', 'divinr', 'sear', 'wizrd',
                'dragn', 'sayg', 'heru', 'champyun', 'saje', 'behemoth', 'rayvn',
                'wizerd', 'seer', 'herald', 'preest', 'templor', 'archmayg', 'knight',
                'juglar', 'litch', 'gargoyl', 'arbitar', 'avatar', 'titan', 'colosus',
                'ravagr', 'zelot', 'nightmar', 'seraf', 'wrath', 'ayngel', 'reavr',
                'inferno', 'stormbringa', 'grym', 'vorteks', 'shrowd', 'wrayth', 'daymon',
                'shayd', 'serpant', 'ohmen', 'feenix', 'enygma', 'novah', 'dredd',
                'vangard', 'hex', 'talon', 'riptyd', 'qwake', 'playg', 'warden',
                'fury', 'eklips', 'havok', 'onyx', 'spekter', 'venjeance', 'myrage',
                'outla', 'broot', 'jynx', 'revenj', 'relyk', 'famyn', 'sylence',
                'kaos', 'ravaje', 'arkanist', 'sfynx', 'hantor', 'marshul', 'rekon',
                'knightmar', 'furius', 'howl', 'bayne', 'nekro', 'scyth', 'spektral',
                'rathful', 'selestial', 'demon', 'anarky', 'envoye', 'helyx', 'torment',
                'dusk', 'brymstone', 'tempest', 'vyper', 'enchant', 'helhound', 'syren',
                'sayber', 'klaw', 'brawlr', 'hontar', 'predator', 'levyathan', 'trikster',
                'run', 'faln', 'dume', 'nightshayd', 'omynous', 'spectral', 'gale',
                'shyver', 'blud', 'hollo', 'warden', 'barbaryan', 'daemon', 'frostbyt',
                'blade', 'sumonar', 'chaos', 'warden', 'eklypse', 'tundra', 'vigyl',
                'emperar', 'haunt', 'infernl', 'helfire', 'roge', 'bludlust', 'torch',
                'raidr', 'shadohfang', 'tytan', 'blakout', 'eqinox', 'inqisitor', 'oblivion',
                'nomad', 'mune', 'skourge', 'bane', 'thundar', 'obsydian', 'sevr', 'reaper',
                'cyclon', 'leegion', 'maulr', 'fantasm', 'wyldfire', 'azral', 'keepr',
                'brygand', 'havoc', 'spyrit', 'ranger', 'doomslayr', 'warden', 'stryker',
                'flare', 'vortex', 'eklipse', 'maylstrom', 'pyro', 'thorn', 'rampage',
                'redemr', 'sentry', 'vigilant', 'myst', 'warden', 'helyon', 'lytning',
                'wyld', 'raze', 'demys', 'nightfal', 'trans', 'rebrn', 'dusk', 'cleavr',
                'reavr', 'anoobis', 'valyant', 'warden', 'tundra', 'hunter', 'recon', 'zephir',
                'envi', 'phantom', 'noks', 'ember', 'aysh', 'werd', 'wrath', 'voyd', 'eagl',
                'stalkr', 'warden', 'falkon', 'spekter', 'hownd', 'tyde', 'thundr',
                'warrior', 'phantom', 'embr', "69", "metl", "Jems", ".rarityy", "smorez",
                'Conqueror', 'Vanquisher', 'Destroyer', 'Paladin', 'Mage', 'Sorcerer', 'Witcher', 'Cleric', 'Monk',
                'Barbarian', 'Thief', 'Bard', 'Jester', 'King', 'Queen', 'Prince', 'Lord',
                'Duke', 'Baron', 'Serf', 'Peasant', 'Emperor', 'Sultan', 'Pharaoh', 'Czar',
                'Shogun', 'Ronin', 'Gunslinger', 'Spaceman', 'Alien', 'Android', 'Cyborg', 'Robot',
                'Mech', 'Pilot', 'Captain', 'Commander', 'Admiral', 'General', 'Soldier', 'Marine',
                'Sniper', 'Spy', 'Agent', 'Detective', 'Bounty', 'Pirate', 'Viking', 'Samurai',
                'Priest', 'Cultist', 'Devil', 'God', 'Giant', 'Golem', 'Wyvern',
                'Griffin', 'Unicorn', 'Pegasus', 'Sphinx', 'Hydra', 'Kraken', 'Leviathan', 'Behemoth',
                'Cerberus', 'Chimera', 'Cyclops', 'Minotaur', 'Centaur', 'Satyr', 'Faun', 'Elf',
                'Dwarf', 'Orc', 'Goblin', 'Troll', 'Ogre', 'Fairy', 'Pixie', 'Nymph', 'Siren',
                'Mermaid', 'Harpy', 'Zombie', 'Vampire', 'Werewolf', 'Ghoul', 'Mummy',
                'Revenant', 'Golem', 'Entity', 'Anomaly', 'Creature', 'Monster', 'Specter', 'Menace',
                'Terror', 'Horror', 'Nightmare', 'Dream', 'Illusion', 'Mirage', 'Oasis', 'Prophet',
                'Oracle', 'Seer', 'Shaman', 'Witchdoctor', 'Healer', 'Alchemist', 'Artificer', 'Inventor',
                'Mechanic', 'Engineer', 'Scientist', 'Explorer', 'Adventurer', 'Traveler', 'Wanderer', 'Nomad',
                'Pilgrim', 'Hermit', 'Recluse', 'Outcast', 'Exile', 'Renegade', 'Rebel', 'Traitor',
                'Patriot', 'Hero', 'Villain', 'Antihero', 'Protagonist', 'Antagonist', 'Nemesis', 'Rival',
                'Ally', 'Friend', 'Foe', 'Enemy', 'Comrade', 'Partner', 'Sidekick', 'Mentor',
                'Apprentice', 'Student', 'Teacher', 'Master', 'Sensi', 'Guru', 'Philosopher', 'Poet',
                'Artist', 'Musician', 'Dancer', 'Actor', 'Storyteller', 'Librarian', 'Scribe', 'Scholar',
                'Judge', 'Jury', 'Lawyer', 'Executioner', 'Gladiator', 'Champion', 'Victor', 'Loser',
                'Survivor', 'Victim', 'Martyr', 'Saint', 'Sinner', 'Believer', 'Atheist', 'Agnostic',
                'Zealot', 'Fanatic', 'Heretic', 'Inquisitor', 'Crusader', 'Jihadi', 'Templar', 'Hospitaller'
            ];

            const rareWords = [
                'addiqutez', 'seriphx', 'coruzv', 'vibantq', 'floruxy', 'zephyx', 'nirvos',
                'quazic', 'mynthox', 'cyren', 'kylithz', 'drakum', 'pharyx', 'syntra',
                'lyrith', 'vertox', 'zorven', 'xanthe', 'quorix', 'vanyth', 'nytrox',
                'zaryn', 'cryptos', 'faylix', 'razion', 'strixum', 'oryphe', 'jynque',
                'talyx', 'voryx', 'myrthos', 'zanith', 'xalith', 'feryss', 'ixtren',
                'graven', 'sorvex', 'voxen', 'quorim', 'myrven', 'cyrix', 'norvyn',
                'xylith', 'trynix', 'zaryn', 'kythir', 'drovyn', 'zypher', 'vorlun',
                'xantho', 'pharynx', 'nirvax', 'quoryn', 'lydrin', 'sylar', 'vorlen',
                'xenith', 'nythos', 'zyven', 'pythos', 'nyxrin', 'vyrnix', 'quorin',
                'lyrith', 'xornix', 'trynth', 'vorlux', 'zythir', 'dyntho', 'phylith',
                'synth', 'noryx', 'zylith', 'trynx', 'xandor', 'voryth', 'phynix',
                'nalyth', 'zymir', 'kythos', 'dorvix', 'xalor', 'phorix', 'nalith',
                'zymoth', 'korvyn', 'xylor', 'pyrix', 'noryx', 'zylor', 'vynth',
                'xandor', 'phyrith', 'koryx', 'dorven', 'zymor', 'nalor', 'korvyn',
                'xyrith', 'trynor', 'vorlan', 'zymos', 'pythor', 'doryn', 'zythos',
                'xylith', 'trymor', 'voryth', 'xandro', 'phynor', 'nalox', 'zymoth',
                'koryth', 'dorven', 'zythen', 'lythar', 'xandro', 'vynthor', 'zymos',
                'koryth', 'dorvan', 'zythar', 'xalith', 'tryvor', 'vorlyn', 'zymon',
                'phyrin', 'nalyn', 'zyloth', 'xandro', 'vynthor', 'zymen', 'lythos',
                'xynor', 'koryn', 'dorvix', 'zyther', 'naloth', 'xarnoth', 'vynthor',
                'zymir', 'phyrin', 'nalor', 'zylith', 'xylor', 'trython', 'vorlin',
                'zymor', 'xynor', 'koryx', 'dorven', 'zythox', 'nalor', 'korven',
                'xanthor', 'phyrith', 'nalor', 'zymith', 'korvan', 'xornith', 'phynar',
                'nalor', 'zymor', 'korvan', 'xaroth', 'voryn', 'xanthor', 'phynar',
                'nalith', 'zymor', 'korvan', 'xanith', 'vorlyn', 'zymar', 'phyrith',
                'nalor', 'zymar', 'korvan', 'xaroth', 'voryn', 'xanthar', 'phynar',
                'nalith', 'zymar', 'korvan', 'xornath', 'phorix', 'nalor', 'zymar',
                'korvyn', 'xaroth', 'vorlyn', 'xanthor', 'phynar', 'nalith', 'zymar',
                'koryx', 'dorven', 'zythar', 'xanith', 'vorlin', 'zymar', 'phyrin',
                'nalor', 'zymar', 'korvyn', 'xornith', 'phorix', 'nalor', 'zymar',
                'koryn', 'dorvan', 'zythar', 'xanith', 'vorlyn', 'zymar', 'phyrin',
                'nalor', 'zymar', 'korvyn', 'xornith', 'phorix', 'nalor', 'zymar',
                'clavix', 'drithor', 'valyph', 'zoryth', 'nylorn', 'crynox', 'voraxin',
                'thoryx', 'zypherin', 'morthan', 'pyrixen', 'xantrix', 'vorynex', 'phylor',
                'lymor', 'quynith', 'drovix', 'xyran', 'korythos', 'zylorn', 'phynith',
                'xyntra', 'vornyx', 'mythros', 'zythrax', 'drayven', 'kylor', 'zorvex',
                'pythra', 'noxith', 'zymorix', 'xylorn', 'vorluxen', 'dorynx', 'zyrinth',
                'phorvyn', 'naryn', 'xantros', 'vorynth', 'mynthor', 'quorven', 'lydrith',
                'zorvenyx', 'nithor', 'zymirith', 'thoryn', 'kryntor', 'zylvex', 'vorynx',
                'phynorix', 'cythran', 'vorath', 'zydrin', 'xalvyn', 'trymorix', 'norvix',
                'vynthos', 'zytharix', 'pharynth', 'drovynth', 'quorinex', 'xornyx',
                'naryl', 'zymithor', 'krylen', 'vorathos', 'zymorix', 'lyntar', 'zorvanth',
                'quaryx', 'xynthor', 'pharnyx', 'norynth', 'zymorin', 'cythrax', 'vorynix',
                'thorin', 'zythran', 'mynthar', 'dorynx', 'xylorin', 'pharvyn', 'nalynth',
                'vorith', 'zythron', 'quaryth', 'xalynth', 'dravyn', 'zylorin', 'vorluxith',
                'thorynth', 'pythrin', 'zymith', 'vorlorn', 'xanvyn', 'zorinth', 'narynth',
                'zymorx', 'korvinth', 'xylornith', 'vynthorix', 'zorynth', 'moryx', 'quarth',
                'xanryth', 'phornyx', 'naryx', 'zymorith', 'vorynxith', 'thorinx', 'zylorix',
                'carynth', 'noxvyn', 'voranth', 'zytharon', 'xynthar', 'pharvinth', 'dranthos',
                'vorlynx', 'xalryth', 'korynith', 'vorlinth', 'thynix', 'zylorith', 'vorinthar',
                'xaloryx', 'phorynth', 'nythrin', 'zymorith', 'quorthan', 'xalven', 'korynthos',
                'vornyxith', 'myntharix', 'zythoran', 'pythral', 'dorith', 'xylithen', 'zorathor',
                'norith', 'zymarix', 'vorlen', 'xyntharix', 'thynor', 'zylorinex', 'voranix',
                'zythoren', 'korvynith', 'xylanth', 'pharynix', 'nymor', 'vorlinith', 'zythronix',
                'quarvyn', 'xandroth', 'phorynxith', 'vorlornith', 'zylarix', 'korvynex', 'xylonith',
                'voranthor', 'zythonix', 'kylorn', 'xylorinth', 'vornyxithen', 'zylorinth', 'phornyxith',
                'nymorin', 'vorlornyx', 'zylarith', 'quarvynith', 'xantryn', 'phorynith', 'vorlithen',
                'zymorithen', 'corynith', 'xylonithor', 'vornyth', 'zytharonix', 'thynorix', 'xylorithen',
                'voranixor', 'zymarin', 'quarvinth', 'xantrithor', 'phornyxor', 'nymarix', 'vorlorny',
                'Glimf', 'Blorp', 'Vexia', 'Qorin', 'Zyloth', 'Jynxar', 'Wobbo', 'Fleep', 'Krunk',
                'Spleen', 'Zorp', 'Glurb', 'Snarp', 'Flix', 'Zorp', 'Quib', 'Flarp', 'Zix',
                'Jix', 'Yorp', 'Gloop', 'Snik', 'Flib', 'Klar', 'Zonk', 'Bleep', 'Glarb',
                'Vorp', 'Snerk', 'Plix', 'Zorb', 'Quax', 'Flibbert', 'Gibbet', 'Snorkel',
                'Flumph', 'Grumble', 'Mumble', 'Stumble', 'Crumble', 'Fumble', 'Jumble', 'Tumble',
                'Rumble', 'Bumble', 'Gurgle', 'Wiggle', 'Jiggle', 'Giggle', 'Snuggle', 'Cuddle',
                'Puddle', 'Muddle', 'Huddle', 'Bungle', 'Mingle', 'Jingle', 'Tingle', 'Single',
                'Zizzle', 'Fizzle', 'Drizzle', 'Sizzle', 'Frazzle', 'Dazzle', 'Razzle', 'Guzzle',
                'Nuzzle', 'Puzzle', 'Muzzle', 'Baffle', 'Raffle', 'Waffle', 'Sniffle', 'Snuffle',
                'Ruffle', 'Muffle', 'Scuffle', 'Truffle', 'Shuffle', 'Gaggle', 'Waggle', 'Haggle',
                'Joggle', 'Woggle', 'Boggle', 'Goggle', 'Coggle', 'Cobble', 'Gobble', 'Hobble'
            ];
            // END OF OLYMPIAD-LEVEL UPDATE

            const letters = 'abcdefghijklmnopqrstuvwxyz';

            const usedUsernames = JSON.parse(localStorage.getItem('usedUsernames')) || [];

            function saveUsernameToLog(username) {
                usedUsernames.push(username);
                localStorage.setItem('usedUsernames', JSON.stringify(usedUsernames));
            }

            function isUsernameUsed(username) {
                return usedUsernames.includes(username);
            }

            let username;
            do {
                if (Math.random() > 0.5) {
                    const getRandomItem = (arr) => arr[Math.floor(Math.random() * arr.length)];
                    username = getRandomItem(list1) + getRandomItem(list2) + getRandomItem(list3);
                } else {
                    const rareWord = rareWords[Math.floor(Math.random() * rareWords.length)];
                    const randomLetters = Array.from({ length: 2 + Math.floor(Math.random() * 2) }, () => letters[Math.floor(Math.random() * letters.length)]).join('');
                    username = rareWord + randomLetters;
                }
            } while (isUsernameUsed(username) || username.startsWith('_') || username.length < 3 || username.length > 20);

            saveUsernameToLog(username);
            return username;
        };

        setBirthdayFields();
        setUsernameAndPassword();

        // START OF NEW OLYMPIAD-LEVEL CODE
        // This MutationObserver reactively handles server-side validation errors for the username.
        const validationErrorElement = document.getElementById('signup-usernameInputValidation');
        if (validationErrorElement) {
            const validationObserver = new MutationObserver(() => {
                // Check if the validation element contains any text. An error message from Roblox will populate this.
                const errorMessage = validationErrorElement.textContent.trim();
                if (errorMessage.length > 0) {
                    console.log(`Validation Error Detected: "${errorMessage}". Regenerating credentials.`);
                    // If an error is detected, call the function to generate a new username and password.
                    setUsernameAndPassword();
                }
            });

            // Start observing the target element for changes to its child nodes (like text being added)
            // and character data. This is highly efficient.
            validationObserver.observe(validationErrorElement, {
                childList: true,
                characterData: true,
                subtree: true
            });
        }
        // END OF NEW OLYMPIAD-LEVEL CODE
    }

    const currentUrl = window.location.href.toLowerCase();
    const validUrls = [
        'https://www.roblox.com/',
        'https://www.roblox.com/createaccount'
    ];

    if (validUrls.some(url => currentUrl.startsWith(url)) || currentUrl.includes('createaccount')) {
        createDraggableWindow();
    }
}