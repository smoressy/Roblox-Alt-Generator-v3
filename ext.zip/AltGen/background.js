chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && tab.url.includes('roblox.com')) {
        console.log('Executing script on:', tab.url);
        chrome.scripting.executeScript({
            target: { tabId: tabId },
            function: myCode
        });
    }
});

function myCode() {
    const list1 = [
        'Sky', 'Mystic', 'Shadow', 'Crimson', 'Solar', 'Nebula', 'Lunar', 'Pixel',
        'Quantum', 'Nova', 'Echo', 'Frost', 'Cosmic', 'Blaze', 'Phantom', 'Azure',
        'Glitch', 'Vortex', 'Titan', 'Aether', 'Obsidian', 'Cinder', 'Nimbus',
        'Mirage', 'Phoenix', 'Falcon', 'Rogue', 'Viper', 'Zenith', 'Spectre',
        'Inferno', 'Spectra', 'Striker', 'Vertex', 'Eclipse', 'Pulse', 'Gale',
        'Aurora', 'Tempest', 'Nexus', 'Blitz', 'Fusion', 'Zenith', 'Pyro', 'Spire',
        'Volt', 'Ember', 'Talon', 'Wraith', 'Glimmer', 'Chaos', 'Drift', 'Thorn',
        'Bane', 'Onyx', 'Fury', 'Ember', 'Raven', 'Ember', 'Haze', 'Pheon',
        'Vector', 'Delta', 'Fang', 'Lyric', 'Rune', 'Hex', 'Shroud', 'Blizzard',
        'Dusk', 'Storm', 'Rune', 'Volt', 'Fable', 'Ember', 'Glare', 'Shade',
        'Ridge', 'Whisper', 'Sable', 'Dawn', 'Storm', 'Glare', 'Haven', 'Tide',
        'Crest', 'Comet', 'Pyre', 'Shade', 'Ashen', 'Flare', 'Radiance', 'Wisp',
        'Thorn', 'Horizon', 'Ember', 'Gust', 'Rune', 'Shiver', 'Spike', 'Aura',
        'Glint', 'Nash', 'Vex', 'Shade', 'Wisp', 'Spectra', 'Haze', 'Kite', 'Zephyr', 'Surge', 'Blaze', 'Rift', 'Echo', 'Storm', 'Crest', 'Volt', 'Frost', 'Flame',
        'Pulse', 'Ember', 'Inferno', 'Glare', 'Shade', 'Lunar', 'Nova', 'Spire', 'Mirage', 'Haze',
        'Nimbus', 'Vortex', 'Quasar', 'Aether', 'Pyre', 'Blitz', 'Echo', 'Comet', 'Raven', 'Eclipse',
        'Phantom', 'Aurora', 'Zenith', 'Spectre', 'Titan', 'Cinder', 'Spectra', 'Obsidian', 'Dawn', 'Lyric',
        'Radiance', 'Glimmer', 'Tempest', 'Bane', 'Gale', 'Wraith', 'Nebula', 'Flare', 'Blizzard', 'Talon'

    ];

    const list2 = [
        '', '', '', '_', 'x', 'z', 'q', '_x', '_z', 'xx', 'zz', 'xz', 'zx',
        'qx', 'zx', 'loves', 'with', 'and', 'vs', 'on', '_vs', '_and', '_with',
        'xwith', 'zwith', 'qwith', 'xand', 'zand', 'qand', '_loves', '_on',
        '_in', 'xin', 'zin', 'qin', 'xvs', 'zvs', 'qvs', 'xvs_', 'zvs_',
        'qvs_', 'onx', 'onz', 'onq', 'withx', 'withz', 'withq', 'andx',
        'andz', 'andq', '_withx', '_withz', '_withq', 'xxand', 'zzand',
        'xzand', 'zxand', '_onx', '_onz', '_onq', 'lovesx', 'lovesz', 'lovesq',
        'onwith', 'withand', 'onand', 'withvs', 'andvs', 'onvs', 'invs',
        'inwith', 'inand', 'inloves', 'loveswith', 'lovesand', 'onloves',
        "olive", "butter", "love"
    ];

    const list3 = [
        'hunter', 'legend', 'warrior', 'mystic', 'slayer', 'seeker', 'shadow',
        'storm', 'blade', 'ghost', 'knight', 'raider', 'rider', 'venom', 'flare',
        'frost', 'reaper', 'spark', 'cypher', 'drift', 'echo', 'strike',
        'vengeance', 'ranger', 'vision', 'scout', 'shift', 'rage', 'force',
        'pulse', 'phantom', 'druid', 'savage', 'fury', 'prowler', 'wrath',
        'flame', 'curse', 'alpha', 'sentinel', 'dragoon', 'harbinger', 'gale',
        'ninja', 'whisper', 'valkyrie', 'tyrant', 'warden', 'prowler', 'skull',
        'revenant', 'witch', 'oracle', 'warlock', 'maiden', 'spear', 'berserker',
        'magus', 'juggernaut', 'swordsman', 'guardian', 'executioner', 'lich',
        'warrior', 'samurai', 'assassin', 'necromancer', 'banshee', 'herald',
        'beast', 'gladiator', 'noble', 'archer', 'diviner', 'seer', 'wizard',
        'dragon', 'sage', 'hero', 'champion', 'sage', 'behemoth', 'raven',
        'wizard', 'seer', 'herald', 'priest', 'templar', 'archmage', 'knight',
        'juggler', 'lich', 'gargoyle', 'arbiter', 'avatar', 'titan', 'colossus',
        'ravager', 'zealot', 'nightmare', 'seraph', 'wrath', 'angel', 'reaver',
        'inferno', 'stormbringer', 'grim', 'vortex', 'shroud', 'wraith', 'daemon',
        'shade', 'serpent', 'omen', 'phoenix', 'enigma', 'nova', 'dread',
        'vanguard', 'hex', 'talon', 'riptide', 'quake', 'plague', 'warden',
        'fury', 'eclipse', 'havoc', 'onyx', 'specter', 'vengeance', 'mirage',
        'outlaw', 'brute', 'jinx', 'revenge', 'relic', 'famine', 'silence',
        'chaos', 'ravage', 'arcanist', 'sphinx', 'hunter', 'marshal', 'recon',
        'knightmare', 'furious', 'howl', 'bane', 'necro', 'scythe', 'spectral',
        'wrathful', 'celestial', 'demon', 'anarchy', 'envoy', 'helix', 'torment',
        'dusk', 'brimstone', 'tempest', 'viper', 'enchant', 'hellhound', 'siren',
        'saber', 'claw', 'brawler', 'hunter', 'predator', 'leviathan', 'trickster',
        'rune', 'fallen', 'doom', 'nightshade', 'ominous', 'spectral', 'gale',
        'shiver', 'blood', 'hollow', 'warden', 'barbarian', 'daemon', 'frostbite',
        'blade', 'summoner', 'chaos', 'warden', 'eclipse', 'tundra', 'vigil',
        'emperor', 'haunt', 'infernal', 'hellfire', 'rogue', 'bloodlust', 'torch',
        'raider', 'shadowfang', 'titan', 'blackout', 'equinox', 'inquisitor', 'oblivion',
        'nomad', 'moon', 'scourge', 'bane', 'thunder', 'obsidian', 'sever', 'reaper',
        'cyclone', 'legion', 'mauler', 'phantasm', 'wildfire', 'azrael', 'keeper',
        'brigand', 'havoc', 'spirit', 'ranger', 'doomslayer', 'warden', 'striker',
        'flare', 'vortex', 'eclipse', 'maelstrom', 'pyro', 'thorn', 'rampage',
        'redeemer', 'sentry', 'vigilante', 'myst', 'warden', 'hellion', 'lightning',
        'wild', 'raze', 'demise', 'nightfall', 'trance', 'reborn', 'dusk', 'cleaver',
        'reaver', 'anubis', 'valiant', 'warden', 'tundra', 'hunter', 'recon', 'zephyr',
        'envy', 'phantom', 'nox', 'ember', 'ash', 'ward', 'wrath', 'void', 'eagle',
        'stalker', 'warden', 'falcon', 'specter', 'hound', 'tide', 'thunder',
        'warrior', 'phantom', 'ember', "69", "metal", "Gems", ".rarity", "smores"
    ];

    const rareWords = [
        'addiqute', 'seriph', 'coruze', 'vibant', 'florux', 'zephyx', 'nirvos',
        'quazic', 'myntho', 'cyrene', 'kylith', 'drakum', 'pharyx', 'syntra',
        'lyrith', 'vertox', 'zorven', 'xanthe', 'quorix', 'vanyth', 'nytrox',
        'zaryn', 'cryptos', 'faylix', 'razion', 'strixum', 'oryphe', 'jynque',
        'talyx', 'voryx', 'myrthos', 'zanith', 'xalith', 'feryss', 'ixtren',
        'graven', 'sorvex', 'voxen', 'quorim', 'myrven', 'cyrix', 'norvyn',
        'xylith', 'trynix', 'zaryn', 'kythir', 'drovyn', 'zypher', 'vorlun',
        'xantho', 'pharynx', 'nirvax', 'quoryn', 'lydrin', 'sylar', 'vorlen',
        'xenith', 'nythos', 'zyven', 'pythos', 'nyxrin', 'vyrnix', 'quorin',
        'lyrith', 'xornix', 'trynth', 'vorlux', 'zythir', 'dyntho', 'phylith',
        'synth', 'noryx', 'zylith', 'trynx', 'xandor', 'voryth', 'phynix',
        'nalyth', 'zymir', 'kythos', 'dorvix', 'xalor', 'phorix', 'nalith',
        'zymoth', 'korvyn', 'xylor', 'pyrix', 'noryx', 'zylor', 'vynth',
        'xandor', 'phyrith', 'koryx', 'dorven', 'zymor', 'nalor', 'korvyn',
        'xyrith', 'trynor', 'vorlan', 'zymos', 'pythor', 'doryn', 'zythos',
        'xylith', 'trymor', 'voryth', 'xandro', 'phynor', 'nalox', 'zymoth',
        'koryth', 'dorven', 'zythen', 'lythar', 'xandro', 'vynthor', 'zymos',
        'koryth', 'dorvan', 'zythar', 'xalith', 'tryvor', 'vorlyn', 'zymon',
        'phyrin', 'nalyn', 'zyloth', 'xandro', 'vynthor', 'zymen', 'lythos',
        'xynor', 'koryn', 'dorvix', 'zyther', 'naloth', 'xarnoth', 'vynthor',
        'zymir', 'phyrin', 'nalor', 'zylith', 'xylor', 'trython', 'vorlin',
        'zymor', 'xynor', 'koryx', 'dorven', 'zythox', 'nalor', 'korven',
        'xanthor', 'phyrith', 'nalor', 'zymith', 'korvan', 'xornith', 'phynar',
        'nalor', 'zymor', 'korvan', 'xaroth', 'voryn', 'xanthor', 'phynar',
        'nalith', 'zymor', 'korvan', 'xanith', 'vorlyn', 'zymar', 'phyrith',
        'nalor', 'zymar', 'korvan', 'xaroth', 'voryn', 'xanthar', 'phynar',
        'nalith', 'zymar', 'korvan', 'xornath', 'phorix', 'nalor', 'zymar',
        'korvyn', 'xaroth', 'vorlyn', 'xanthor', 'phynar', 'nalith', 'zymar',
        'koryx', 'dorven', 'zythar', 'xanith', 'vorlin', 'zymar', 'phyrin',
        'nalor', 'zymar', 'korvyn', 'xornith', 'phorix', 'nalor', 'zymar',
        'koryn', 'dorvan', 'zythar', 'xanith', 'vorlyn', 'zymar', 'phyrin',
        'nalor', 'zymar', 'korvyn', 'xornith', 'phorix', 'nalor', 'zymar',
        'clavix', 'drithor', 'valyph', 'zoryth', 'nylorn', 'crynox', 'voraxin',
        'thoryx', 'zypherin', 'morthan', 'pyrixen', 'xantrix', 'vorynex', 'phylor',
        'lymor', 'quynith', 'drovix', 'xyran', 'korythos', 'zylorn', 'phynith',
        'xyntra', 'vornyx', 'mythros', 'zythrax', 'drayven', 'kylor', 'zorvex',
        'pythra', 'noxith', 'zymorix', 'xylorn', 'vorluxen', 'dorynx', 'zyrinth',
        'phorvyn', 'naryn', 'xantros', 'vorynth', 'mynthor', 'quorven', 'lydrith',
        'zorvenyx', 'nithor', 'zymirith', 'thoryn', 'kryntor', 'zylvex', 'vorynx',
        'phynorix', 'cythran', 'vorath', 'zydrin', 'xalvyn', 'trymorix', 'norvix',
        'vynthos', 'zytharix', 'pharynth', 'drovynth', 'quorinex', 'xornyx',
        'naryl', 'zymithor', 'krylen', 'vorathos', 'zymorix', 'lyntar', 'zorvanth',
        'quaryx', 'xynthor', 'pharnyx', 'norynth', 'zymorin', 'cythrax', 'vorynix',
        'thorin', 'zythran', 'mynthar', 'dorynx', 'xylorin', 'pharvyn', 'nalynth',
        'vorith', 'zythron', 'quaryth', 'xalynth', 'dravyn', 'zylorin', 'vorluxith',
        'thorynth', 'pythrin', 'zymith', 'vorlorn', 'xanvyn', 'zorinth', 'narynth',
        'zymorx', 'korvinth', 'xylornith', 'vynthorix', 'zorynth', 'moryx', 'quarth',
        'xanryth', 'phornyx', 'naryx', 'zymorith', 'vorynxith', 'thorinx', 'zylorix',
        'carynth', 'noxvyn', 'voranth', 'zytharon', 'xynthar', 'pharvinth', 'dranthos',
        'vorlynx', 'xalryth', 'korynith', 'vorlinth', 'thynix', 'zylorith', 'vorinthar',
        'xaloryx', 'phorynth', 'nythrin', 'zymorith', 'quorthan', 'xalven', 'korynthos',
        'vornyxith', 'myntharix', 'zythoran', 'pythral', 'dorith', 'xylithen', 'zorathor',
        'norith', 'zymarix', 'vorlen', 'xyntharix', 'thynor', 'zylorinex', 'voranix',
        'zythoren', 'korvynith', 'xylanth', 'pharynix', 'nymor', 'vorlinith', 'zythronix',
        'quarvyn', 'xandroth', 'phorynxith', 'vorlornith', 'zylarix', 'korvynex', 'xylonith',
        'voranthor', 'zythonix', 'kylorn', 'xylorinth', 'vornyxithen', 'zylorinth', 'phornyxith',
        'nymorin', 'vorlornyx', 'zylarith', 'quarvynith', 'xantryn', 'phorynith', 'vorlithen',
        'zymorithen', 'corynith', 'xylonithor', 'vornyth', 'zytharonix', 'thynorix', 'xylorithen',
        'voranixor', 'zymarin', 'quarvinth', 'xantrithor', 'phornyxor', 'nymarix', 'vorlorny'

    ];
    (function () {
        const url = window.location.href;
        if (url.startsWith("https://www.roblox.com/CreateAccount") || url === "https://www.roblox.com/") {
            window.scrollTo(0, document.body.scrollHeight);
        }
    })();

    function attemptClick() {
        const signUpButton = document.querySelector('#sign-up-button');
        if (signUpButton) {
            console.log("eureka!");
            signUpButton.click();
            clearInterval(intervalId);
        }
    }

    const intervalId = setInterval(attemptClick, 0);

    const inputElement = document.getElementById('signup-username');
    const hiddenTextArea = document.createElement('textarea');
    hiddenTextArea.style.position = 'fixed';
    hiddenTextArea.style.opacity = '0';
    hiddenTextArea.style.pointerEvents = 'none';
    document.body.appendChild(hiddenTextArea);

    function copyValueToClipboard() {
        const inputValue = inputElement.value;
        hiddenTextArea.value = inputValue;
        hiddenTextArea.select();
        hiddenTextArea.setSelectionRange(0, inputValue.length);

        try {
            document.execCommand('copy');
            console.log('Copied to clipboard:', inputValue);
        } catch (err) {
            console.error('Failed to copy:', err);
        }
    }
    setInterval(copyValueToClipboard, 100);

    (function () {
        (function togglePasswordVisibility() {
            const targetButtonSelector = 'div[role="button"].icon-password-show-v2.icon-password-show.password-visibility-toggle[aria-label="toggle-password-visibility"]';
            const changedButtonSelector = 'div[role="button"].icon-password-hide-v2.icon-password-show.password-visibility-toggle[aria-label="toggle-password-visibility"]';

            function checkAndClickButton() {
                const button = document.querySelector(targetButtonSelector);
                if (button) {
                    button.click();
                    requestAnimationFrame(() => {
                        const changedButton = document.querySelector(changedButtonSelector);
                        if (!changedButton) {
                            checkAndClickButton();
                        }
                    });
                }
            }
            requestAnimationFrame(checkAndClickButton);
        })();

        function dispatchChangeEvent(element) {
            const event = new Event('change', { bubbles: true });
            element.dispatchEvent(event);
        }

        function setNativeValue(element, value) {
            const valueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
            const prototypeValueSetter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(element), 'value').set;
            valueSetter ? valueSetter.call(element, value) : prototypeValueSetter.call(element, value);
        }

        function simulateUserInput(inputElement, value) {
            setNativeValue(inputElement, value);
            inputElement.dispatchEvent(new Event('input', { bubbles: true }));
        }

        function generateRandomText() {
            const letters = 'abcdefghijklmnopqrstuvwxyz';
            const useLegacySystem = Math.random() > 0.5;
            let username;

            if (useLegacySystem) {
                const getRandomItem = (arr) => arr[Math.floor(Math.random() * arr.length)];
                username = getRandomItem(list1) + getRandomItem(list2) + getRandomItem(list3);
            } else {
                const rareWord = rareWords[Math.floor(Math.random() * rareWords.length)];
                const randomLetters = Array.from({ length: 2 + Math.floor(Math.random() * 2) }, () => letters[Math.floor(Math.random() * letters.length)]).join('');
                username = rareWord + randomLetters;
            }
            if (username.startsWith('_') || username.length < 3 || username.length > 20) {
                return generateRandomText();
            }

            setPassword(username);
            return username;
        }

        function setPassword(username) {
            const passwordField = document.querySelector('#signup-password');
            if (passwordField) {
                const password = username + username;
                simulateUserInput(passwordField, password);
            } else {
                console.log('Password field not found');
            }
        }

        function setUsername() {
            const inputField = document.querySelector('#signup-username');
            if (inputField) {
                const username = generateRandomText();
                simulateUserInput(inputField, username);
            } else {
                console.log('Input field not found');
            }
        }

        function checkIfUsernameInUse() {
            const errorMessage = document.querySelector('#signup-usernameInputValidation');
            if (errorMessage) {
                const errorMessageText = errorMessage.textContent.trim();
                return [
                    "This username is already in use.",
                    "Username not appropriate for Roblox.",
                    "Usernames can be 3 to 20 characters long.",
                    "Usernames cannot start or end with _.",
                    "Usernames can have at most one _."
                ].includes(errorMessageText);
            }
            return false;
        }

        const observer = new MutationObserver((mutations) => {
            mutations.forEach(() => {
                if (checkIfUsernameInUse()) {
                    setUsername();
                }
            });
        });

        const validationElement = document.querySelector('#signup-usernameInputValidation');
        if (validationElement) {
            observer.observe(validationElement, { childList: true });
        }

        const usernameInput = document.querySelector('#signup-username');
        if (usernameInput) {
            usernameInput.addEventListener('input', () => {
                setPassword(usernameInput.value);
            });
        }

        const acceptBtnObserver = new MutationObserver(() => {
            const acceptBtn = document.querySelector('.btn-cta-lg.cookie-btn.btn-primary-md.btn-min-width');
            if (acceptBtn) {
                acceptBtn.click();
                acceptBtnObserver.disconnect();
            }
        });

        acceptBtnObserver.observe(document.body, { childList: true, subtree: true });

        const yearDropdown = document.querySelector('#YearDropdown');
        const monthDropdown = document.querySelector('#MonthDropdown');
        const dayDropdown = document.querySelector('#DayDropdown');

        if (yearDropdown && monthDropdown && dayDropdown) {
            yearDropdown.value = '2000';
            dispatchChangeEvent(yearDropdown);
            monthDropdown.value = 'Jan';
            dispatchChangeEvent(monthDropdown);
            dayDropdown.value = '01';
            dispatchChangeEvent(dayDropdown);
        } else {
            console.log('Could not find the birthday input fields.');
        }

        setUsername();
    })();
}