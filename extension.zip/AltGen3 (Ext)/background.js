chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && tab.url.includes('roblox.com')) {
        console.log('Executing script on:', tab.url);
        chrome.scripting.executeScript({
            target: { tabId: tabId },
            function: myCode
        });
    }
});

function myCode() {
    // START
    (function () {
        (function togglePasswordVisibility() {
            const targetButtonSelector = 'div[role="button"].icon-password-show-v2.icon-password-show.password-visibility-toggle[aria-label="toggle-password-visibility"]';
            const changedButtonSelector = 'div[role="button"].icon-password-hide-v2.icon-password-show.password-visibility-toggle[aria-label="toggle-password-visibility"]';

            function checkAndClickButton() {
                const button = document.querySelector(targetButtonSelector);

                if (button) {
                    button.click();
                    setTimeout(() => {
                        const changedButton = document.querySelector(changedButtonSelector);
                        if (!changedButton) {
                            checkAndClickButton();
                        }
                    }, 15);
                }
            }

            setInterval(checkAndClickButton, 15);
        })();

        function dispatchChangeEvent(element) {
            const event = new Event('change', { bubbles: true });
            element.dispatchEvent(event);
        }

        function setNativeValue(element, value) {
            const valueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
            const prototypeValueSetter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(element), 'value').set;
            valueSetter ? valueSetter.call(element, value) : prototypeValueSetter.call(element, value);
        }

        function simulateUserInput(inputElement, value) {
            setNativeValue(inputElement, value);
            inputElement.dispatchEvent(new Event('input', { bubbles: true }));
        }

        function generateRandomText() {
            const list1 = [
                'Sky', 'Mystic', 'Shadow', 'Crimson', 'Solar', 'Nebula', 'Lunar', 'Pixel', 
                'Quantum', 'Nova', 'Echo', 'Frost', 'Cosmic', 'Blaze', 'Phantom', 'Azure', 
                'Glitch', 'Vortex', 'Titan', 'Aether', 'Obsidian', 'Cinder', 'Nimbus', 
                'Mirage', 'Phoenix', 'Falcon', 'Rogue', 'Viper', 'Zenith', 'Spectre', 
                'Inferno', 'Spectra', 'Striker', 'Vertex', 'Eclipse', 'Pulse', 'Gale', 
                'Aurora', 'Tempest', 'Nexus', 'Blitz', 'Fusion', 'Zenith', 'Pyro', 'Spire', 
                'Volt', 'Ember', 'Talon', 'Wraith', 'Glimmer', 'Chaos', 'Drift', 'Thorn', 
                'Bane', 'Onyx', 'Fury', 'Ember', 'Raven', 'Ember', 'Haze', 'Pheon', 
                'Vector', 'Delta', 'Fang', 'Lyric', 'Rune', 'Hex', 'Shroud', 'Blizzard', 
                'Dusk', 'Storm', 'Rune', 'Volt', 'Fable', 'Ember', 'Glare', 'Shade', 
                'Ridge', 'Whisper', 'Sable', 'Dawn', 'Storm', 'Glare', 'Haven', 'Tide', 
                'Crest', 'Comet', 'Pyre', 'Shade', 'Ashen', 'Flare', 'Radiance', 'Wisp', 
                'Thorn', 'Horizon', 'Ember', 'Gust', 'Rune', 'Shiver', 'Spike', 'Aura', 
                'Glint', 'Nash', 'Vex', 'Shade', 'Wisp', 'Spectra', 'Haze', 'Kite'
              ];
              
              const list2 = [
                '', '', '', '_', 'x', 'z', 'q', '_x', '_z', 'xx', 'zz', 'xz', 'zx', 
                'qx', 'zx', 'loves', 'with', 'and', 'vs', 'on', '_vs', '_and', '_with', 
                'xwith', 'zwith', 'qwith', 'xand', 'zand', 'qand', '_loves', '_on', 
                '_in', 'xin', 'zin', 'qin', 'xvs', 'zvs', 'qvs', 'xvs_', 'zvs_', 
                'qvs_', 'onx', 'onz', 'onq', 'withx', 'withz', 'withq', 'andx', 
                'andz', 'andq', '_withx', '_withz', '_withq', 'xxand', 'zzand', 
                'xzand', 'zxand', '_onx', '_onz', '_onq', 'lovesx', 'lovesz', 'lovesq', 
                'onwith', 'withand', 'onand', 'withvs', 'andvs', 'onvs', 'invs', 
                'inwith', 'inand', 'inloves', 'loveswith', 'lovesand', 'onloves'
              ];              
              
              const list3 = [
                'hunter', 'legend', 'warrior', 'mystic', 'slayer', 'seeker', 'shadow', 
                'storm', 'blade', 'ghost', 'knight', 'raider', 'rider', 'venom', 'flare', 
                'frost', 'reaper', 'spark', 'cypher', 'drift', 'echo', 'strike', 
                'vengeance', 'ranger', 'vision', 'scout', 'shift', 'rage', 'force', 
                'pulse', 'phantom', 'druid', 'savage', 'fury', 'prowler', 'wrath', 
                'flame', 'curse', 'alpha', 'sentinel', 'dragoon', 'harbinger', 'gale', 
                'ninja', 'whisper', 'valkyrie', 'tyrant', 'warden', 'prowler', 'skull', 
                'revenant', 'witch', 'oracle', 'warlock', 'maiden', 'spear', 'berserker', 
                'magus', 'juggernaut', 'swordsman', 'guardian', 'executioner', 'lich', 
                'warrior', 'samurai', 'assassin', 'necromancer', 'banshee', 'herald', 
                'beast', 'gladiator', 'noble', 'archer', 'diviner', 'seer', 'wizard', 
                'dragon', 'sage', 'hero', 'champion', 'sage', 'behemoth', 'raven', 
                'wizard', 'seer', 'herald', 'priest', 'templar', 'archmage', 'knight', 
                'juggler', 'lich', 'gargoyle', 'arbiter', 'avatar', 'titan', 'colossus', 
                'ravager', 'zealot', 'nightmare', 'seraph', 'wrath', 'angel', 'reaver'
              ];
              
              const rareWords = [
                'addiqute', 'seriph', 'coruze', 'vibant', 'florux', 'zephyx', 'nirvos', 
                'quazic', 'myntho', 'cyrene', 'kylith', 'drakum', 'pharyx', 'syntra', 
                'lyrith', 'vertox', 'zorven', 'xanthe', 'quorix', 'vanyth', 'nytrox', 
                'zaryn', 'cryptos', 'faylix', 'razion', 'strixum', 'oryphe', 'jynque', 
                'talyx', 'voryx', 'myrthos', 'zanith', 'xalith', 'feryss', 'ixtren', 
                'graven', 'sorvex', 'voxen', 'quorim', 'myrven', 'cyrix', 'norvyn', 
                'xylith', 'trynix', 'zaryn', 'kythir', 'drovyn', 'zypher', 'vorlun', 
                'xantho', 'pharynx', 'nirvax', 'quoryn', 'lydrin', 'sylar', 'vorlen', 
                'xenith', 'nythos', 'zyven', 'pythos', 'nyxrin', 'vyrnix', 'quorin', 
                'lyrith', 'xornix', 'trynth', 'vorlux', 'zythir', 'dyntho', 'phylith', 
                'synth', 'noryx', 'zylith', 'trynx', 'xandor', 'voryth', 'phynix', 
                'nalyth', 'zymir', 'kythos', 'dorvix', 'xalor', 'phorix', 'nalith', 
                'zymoth', 'korvyn', 'xylor', 'pyrix', 'noryx', 'zylor', 'vynth', 
                'xandor', 'phyrith', 'koryx', 'dorven', 'zymor', 'nalor', 'korvyn', 
                'xyrith', 'trynor', 'vorlan', 'zymos', 'pythor', 'doryn', 'zythos', 
                'xylith', 'trymor', 'voryth', 'xandro', 'phynor', 'nalox', 'zymoth', 
                'koryth', 'dorven', 'zythen', 'lythar', 'xandro', 'vynthor', 'zymos', 
                'koryth', 'dorvan', 'zythar', 'xalith', 'tryvor', 'vorlyn', 'zymon', 
                'phyrin', 'nalyn', 'zyloth', 'xandro', 'vynthor', 'zymen', 'lythos', 
                'xynor', 'koryn', 'dorvix', 'zyther', 'naloth', 'xarnoth', 'vynthor', 
                'zymir', 'phyrin', 'nalor', 'zylith', 'xylor', 'trython', 'vorlin', 
                'zymor', 'xynor', 'koryx', 'dorven', 'zythox', 'nalor', 'korven', 
                'xanthor', 'phyrith', 'nalor', 'zymith', 'korvan', 'xornith', 'phynar', 
                'nalor', 'zymor', 'korvan', 'xaroth', 'voryn', 'xanthor', 'phynar', 
                'nalith', 'zymor', 'korvan', 'xanith', 'vorlyn', 'zymar', 'phyrith', 
                'nalor', 'zymar', 'korvan', 'xaroth', 'voryn', 'xanthar', 'phynar', 
                'nalith', 'zymar', 'korvan', 'xornath', 'phorix', 'nalor', 'zymar', 
                'korvyn', 'xaroth', 'vorlyn', 'xanthor', 'phynar', 'nalith', 'zymar', 
                'koryx', 'dorven', 'zythar', 'xanith', 'vorlin', 'zymar', 'phyrin', 
                'nalor', 'zymar', 'korvyn', 'xornith', 'phorix', 'nalor', 'zymar', 
                'koryn', 'dorvan', 'zythar', 'xanith', 'vorlyn', 'zymar', 'phyrin', 
                'nalor', 'zymar', 'korvyn', 'xornith', 'phorix', 'nalor', 'zymar'
              ];
              
              const letters = 'abcdefghijklmnopqrstuvwxyz'.split('');
              
            const useLegacySystem = Math.random() > 0.5;
            let username;

            if (useLegacySystem) {
                const getRandomItem = (arr) => arr[Math.floor(Math.random() * arr.length)];
                username = getRandomItem(list1) + getRandomItem(list2) + getRandomItem(list3);
            } else {
                const rareWord = rareWords[Math.floor(Math.random() * rareWords.length)];
                const randomLetters = Array.from({ length: 2 + Math.floor(Math.random() * 2) }, () => letters[Math.floor(Math.random() * letters.length)]).join('');
                username = rareWord + randomLetters;
            }

            setPassword(username);
            return username;
        }

        function setPassword(username) {
            const passwordField = document.querySelector('#signup-password');
            if (passwordField) {
                const password = username + username;
                simulateUserInput(passwordField, password);
            } else {
                console.log('Password field not found');
            }
        }

        function setUsername() {
            const inputField = document.querySelector('#signup-username');
            if (inputField) {
                const username = generateRandomText();
                simulateUserInput(inputField, username);
            } else {
                console.log('Input field not found');
            }
        }

        function checkIfUsernameInUse() {
            const errorMessage = document.querySelector('#signup-usernameInputValidation');
            if (errorMessage) {
                const errorMessageText = errorMessage.textContent.trim();
                return [
                    "This username is already in use.",
                    "Username not appropriate for Roblox.",
                    "Usernames can be 3 to 20 characters long.",
                    "Usernames cannot start or end with _.",
                    "Usernames can have at most one _."
                ].includes(errorMessageText);
            }
            return false;
        }

        const observer = new MutationObserver((mutations) => {
            mutations.forEach(() => {
                if (checkIfUsernameInUse()) {
                    setUsername();
                }
            });
        });

        observer.observe(document.querySelector('#signup-usernameInputValidation'), { childList: true });

        const usernameInput = document.querySelector('#signup-username');
        if (usernameInput) {
            usernameInput.addEventListener('input', () => {
                setPassword(usernameInput.value);
            });
        }

        window.addEventListener('load', () => {
            setTimeout(() => {
                const button = document.getElementById('MaleButton');
                button?.click();
            }, 250);
        });

        const acceptBtnObserver = new MutationObserver(() => {
            const acceptBtn = document.querySelector('.btn-cta-lg.cookie-btn.btn-primary-md.btn-min-width');
            if (acceptBtn) {
                acceptBtn.click();
                acceptBtnObserver.disconnect();
            }
        });

        acceptBtnObserver.observe(document.body, { childList: true, subtree: true });

        const yearDropdown = document.querySelector('#YearDropdown');
        const monthDropdown = document.querySelector('#MonthDropdown');
        const dayDropdown = document.querySelector('#DayDropdown');

        if (yearDropdown && monthDropdown && dayDropdown) {
            yearDropdown.value = '2000';
            dispatchChangeEvent(yearDropdown);
            monthDropdown.value = 'Jan';
            dispatchChangeEvent(monthDropdown);
            dayDropdown.value = '01';
            dispatchChangeEvent(dayDropdown);
        } else {
            console.log('Could not find the birthday input fields.');
        }

        setUsername();
    })();
    // FINISH
}