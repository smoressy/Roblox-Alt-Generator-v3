// background.js
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && tab.url.includes('roblox.com')) {
      chrome.scripting.executeScript({
        target: { tabId },
        function: contentScript
      });
    }
  });
  
  // content.js (injected as `contentScript`)
  function contentScript() {
    // 1) Inject Google Font
    if (!document.querySelector('link[data-altgen="poppins"]')) {
      const l = document.createElement('link');
      l.rel = 'stylesheet';
      l.href = 'https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap';
      l.setAttribute('data-altgen', 'poppins');
      document.head.append(l);
    }
  
    // 2) Focus username when page loads (or immediately if already loaded)
    const focusUsername = () => document.getElementById('signup-username')?.focus();
    if (document.readyState === 'complete') focusUsername();
    else window.addEventListener('load', focusUsername);
  
    // 3) Every 100ms, copy current username to clipboard
    setInterval(() => {
      const i = document.getElementById('signup-username');
      if (i?.value) {
        navigator.clipboard.writeText(i.value).catch(console.error);
      }
    }, 100);
  
    // 4) Continuously try to click the “Sign Up” button as soon as it appears
    (function tryClick() {
      const btn = document.querySelector('#sign-up-button');
      if (btn) btn.click();
      else requestAnimationFrame(tryClick);
    })();
  
    // 5) Remove unwanted elements via one MutationObserver + initial sweep
    const removeSelectors = ['.terms-agreement', '#app-stores-container'];
    const removeAll = () => {
      removeSelectors.forEach(sel =>
        document.querySelectorAll(sel).forEach(el => el.remove())
      );
    };
    removeAll();
    const mo = new MutationObserver(removeAll);
    mo.observe(document.body, { childList: true, subtree: true });
    document.addEventListener('DOMContentLoaded', removeAll);
  
    // 6) Auto‑scroll to bottom on the account‑creation page for 1.2s
    if (/roblox\.com(\/createaccount)?(\/)?$/i.test(location.href)) {
      const start = performance.now();
      (function scrollLoop() {
        window.scrollTo(0, document.body.scrollHeight);
        if (performance.now() - start < 1200) {
          requestAnimationFrame(scrollLoop);
        }
      })();
    }
  
    // 7) Helpers to set native input value + dispatch events
    const dispatchChange = el => el.dispatchEvent(new Event('change', { bubbles: true }));
    const setNativeValue = (el, val) => {
      const proto = Object.getPrototypeOf(el);
      const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
      setter.call(el, val);
    };
    const simulateInput = (el, val) => {
      setNativeValue(el, val);
      el.dispatchEvent(new Event('input', { bubbles: true }));
    };
  
    // 8) Create the draggable diagnostics window
    (function createDiagnostics() {
      if (!/roblox\.com(\/createaccount)?\/?$/i.test(location.href)) return;
  
      // container
      const c = document.createElement('div');
      c.id = 'altgen-container';
      c.style.cssText =
        'position:fixed;top:10px;left:10px;width:300px;background:#141414;border-radius:10px;box-shadow:0 0 10px rgba(0,0,0,.5);color:#fff;font-family:Poppins,sans-serif;z-index:10000';
  
      // title bar & close
      const tb = document.createElement('div');
      tb.style.cssText =
        'background:#0f0f0f;padding:10px;cursor:move;border-radius:10px 10px 0 0;display:flex;align-items:center;justify-content:space-between';
      const title = document.createElement('span');
      title.textContent = 'AltGen v4 Diagnostics';
      const closeBtn = document.createElement('div');
      closeBtn.style.cssText =
        'width:15px;height:15px;background:#0f0f0f;border-radius:50%;cursor:pointer;transition:transform .2s';
      closeBtn.onclick = () => {
        c.style.transform = 'scale(0)';
        setTimeout(() => c.remove(), 200);
      };
      tb.append(title, closeBtn);
      c.append(tb);
  
      // content & status lines
      const content = document.createElement('div');
      content.style.cssText = 'padding:10px;font-family:Poppins,sans-serif';
      ['Birthday', 'Username', 'Password'].forEach(label => {
        const p = document.createElement('p');
        p.id = label.toLowerCase() + 'Status';
        p.textContent = label + ': N/A';
        content.append(p);
      });
      c.append(content);
      document.body.append(c);
  
      // dragging logic
      let drag = false, dx = 0, dy = 0;
      tb.onpointerdown = e => {
        drag = true;
        dx = e.clientX - c.offsetLeft;
        dy = e.clientY - c.offsetTop;
      };
      document.onpointermove = e => {
        if (drag) {
          c.style.left = e.clientX - dx + 'px';
          c.style.top = e.clientY - dy + 'px';
        }
      };
      document.onpointerup = () => (drag = false);
  
      // generate random gibberish
      function generateGibberish() {
        const L = 20, chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        const useUnder = Math.random() < 0.5;
        const pos = useUnder ? 1 + Math.floor(Math.random() * (L - 2)) : -1;
        let out = '';
        for (let i = 0; i < L; i++) {
          if (i === pos) out += '_';
          else out += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return out;
      }
  
      // 8a) Birthday
      const bs = document.getElementById('birthdayStatus');
      const Y = document.querySelector('#YearDropdown');
      const M = document.querySelector('#MonthDropdown');
      const D = document.querySelector('#DayDropdown');
      if (Y && M && D) {
        setNativeValue(Y, '2000'); dispatchChange(Y);
        setNativeValue(M, 'Dec'); dispatchChange(M);
        setNativeValue(D, '25'); dispatchChange(D);
        const ok = Y.value === '2000' && M.value === 'Dec' && D.value === '25';
        bs.textContent = `Birthday: ${ok ? '✅' : '❌'}`;
        bs.style.color = ok ? 'green' : 'red';
      } else {
        bs.textContent = 'Birthday: ❓';
        bs.style.color = 'yellow';
      }
  
      // 8b) Username & Password
      const uname = generateGibberish();
      const ui = document.querySelector('#signup-username');
      const pi = document.querySelector('#signup-password');
      const us = document.getElementById('usernameStatus');
      const ps = document.getElementById('passwordStatus');
  
      if (ui) simulateInput(ui, uname);
      if (pi) simulateInput(pi, uname + uname);
  
      if (ui) {
        const ok = ui.value === uname;
        us.textContent = `Username: ${ok ? '✅' : '❌'}`;
        us.style.color = ok ? 'green' : 'red';
      } else {
        us.textContent = 'Username: ❓';
        us.style.color = 'yellow';
      }
  
      if (pi) {
        const ok = pi.value === uname + uname;
        ps.textContent = `Password: ${ok ? '✅' : '❌'}`;
        ps.style.color = ok ? 'green' : 'red';
      } else {
        ps.textContent = 'Password: ❓';
        ps.style.color = 'yellow';
      }
    })();
  }