chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && tab.url.includes('roblox.com')) {
        console.log('Executing script on:', tab.url);
        chrome.scripting.executeScript({
            target: { tabId: tabId },
            function: myCode
        });
    }
});

function myCode() {
    // START
if (window.location.href.toLowerCase().includes("/login")) {
    window.location.href = "https://www.roblox.com";
}
const intervalId = setInterval(checkUrl, 10); // Check every 10 milliseconds
    function checkUrl() {
        if (window.location.href === "https://www.roblox.com/Login") {
            window.location.href = "https://www.roblox.com/";
        }
    }

    setInterval(checkUrl, 10); // Check every 10 milliseconds
(function () {
    (function togglePasswordVisibility() {
        const targetButtonSelector = 'div[role="button"].icon-password-show-v2.icon-password-show.password-visibility-toggle[aria-label="toggle-password-visibility"]';
        const changedButtonSelector = 'div[role="button"].icon-password-hide-v2.icon-password-show.password-visibility-toggle[aria-label="toggle-password-visibility"]';

        function checkAndClickButton() {
            const button = document.querySelector(targetButtonSelector);

            if (button) {
                button.click();
                setTimeout(() => {
                    const changedButton = document.querySelector(changedButtonSelector);
                    if (!changedButton) {
                        checkAndClickButton();
                    }
                }, 15);
            }
        }

        setInterval(checkAndClickButton, 15);
    })();

    function dispatchChangeEvent(element) {
        const event = new Event('change', { bubbles: true });
        element.dispatchEvent(event);
    }

    function setNativeValue(element, value) {
        const valueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
        const prototypeValueSetter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(element), 'value').set;
        valueSetter ? valueSetter.call(element, value) : prototypeValueSetter.call(element, value);
    }

    function simulateUserInput(inputElement, value) {
        setNativeValue(inputElement, value);
        inputElement.dispatchEvent(new Event('input', { bubbles: true }));
    }

    function generateRandomText() {
        const characters = 'Il';
        let usernameArray = Array.from({ length: 20 }, () => characters[Math.floor(Math.random() * characters.length)]);
        usernameArray = usernameArray.sort(() => Math.random() - 0.5); // Shuffle the array
        const username = usernameArray.join('');
        setPassword(username);
        return username;
    }

    function setPassword(username) {
        const passwordField = document.querySelector('#signup-password');
        if (passwordField) {
            const password = username + username;
            simulateUserInput(passwordField, password);
        } else {
            console.log('Password field not found');
        }
    }

    function setUsername() {
        const inputField = document.querySelector('#signup-username');
        if (inputField) {
            const username = generateRandomText();
            simulateUserInput(inputField, username);
        } else {
            console.log('Input field not found');
        }
    }

    function checkIfUsernameInUse() {
        const errorMessage = document.querySelector('#signup-usernameInputValidation');
        if (errorMessage) {
            const errorMessageText = errorMessage.textContent.trim();
            return [
                "This username is already in use.",
                "Username not appropriate for Roblox.",
                "Usernames can be 3 to 20 characters long.",
                "Usernames cannot start or end with _.",
                "Usernames can have at most one _."
            ].includes(errorMessageText);
        }
        return false;
    }

    const observer = new MutationObserver((mutations) => {
        mutations.forEach(() => {
            if (checkIfUsernameInUse()) {
                setUsername();
            }
        });
    });

    observer.observe(document.querySelector('#signup-usernameInputValidation'), { childList: true });

    const usernameInput = document.querySelector('#signup-username');
    if (usernameInput) {
        usernameInput.addEventListener('input', () => {
            setPassword(usernameInput.value);
        });
    }

    window.addEventListener('load', () => {
        setTimeout(() => {
            const button = document.getElementById('MaleButton');
            button?.click();
        }, 250);
    });

    const acceptBtnObserver = new MutationObserver(() => {
        const acceptBtn = document.querySelector('.btn-cta-lg.cookie-btn.btn-primary-md.btn-min-width');
        if (acceptBtn) {
            acceptBtn.click();
            acceptBtnObserver.disconnect();
        }
    });

    acceptBtnObserver.observe(document.body, { childList: true, subtree: true });

    const yearDropdown = document.querySelector('#YearDropdown');
    const monthDropdown = document.querySelector('#MonthDropdown');
    const dayDropdown = document.querySelector('#DayDropdown');

    if (yearDropdown && monthDropdown && dayDropdown) {
        yearDropdown.value = '2000';
        dispatchChangeEvent(yearDropdown);
        monthDropdown.value = 'Jan';
        dispatchChangeEvent(monthDropdown);
        dayDropdown.value = '01';
        dispatchChangeEvent(dayDropdown);
    } else {
        console.log('Could not find the birthday input fields.');
    }

    setUsername();
})();
    // FINISH
}